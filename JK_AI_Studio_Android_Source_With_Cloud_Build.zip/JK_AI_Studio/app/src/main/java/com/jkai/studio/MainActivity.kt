package com.jkai.studio

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    // Replace with your deployed backend URL. For local testing, use your computer's LAN IP.
    private val apiUrl = "https://YOUR-BACKEND-URL/generate"
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(240, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private var selectedUri: Uri? = null
    private var resultBytes: ByteArray? = null
    private lateinit var preview: ImageView
    private lateinit var promptBox: EditText
    private lateinit var status: TextView
    private lateinit var generateButton: Button
    private lateinit var mode: RadioGroup

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            contentResolver.openInputStream(uri)?.use { input ->
                preview.setImageBitmap(BitmapFactory.decodeStream(input))
            }
            status.text = "Photo selected. Ab prompt likho."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xFFF5F5FA.toInt())
        }
        scroll.addView(layout)

        fun heading(text: String, size: Float) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFF17172B.toInt())
        }
        layout.addView(heading("JK AI Studio", 28f))
        layout.addView(heading("Create • Edit • Imagine", 14f))
        preview = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, 320).apply { topMargin = 22; bottomMargin = 12 }
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFFE2E2EA.toInt())
        }
        layout.addView(preview)

        val pick = Button(this).apply {
            text = "📷  Upload Photo"
            setOnClickListener { pickImage.launch("image/*") }
        }
        layout.addView(pick)

        layout.addView(heading("Choose mode", 17f).apply { setPadding(0, 18, 0, 4) })
        mode = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val textOnly = RadioButton(this).apply { text = "Text to Image (new photo)"; id = View.generateViewId() }
        val editPhoto = RadioButton(this).apply { text = "Photo to Image (edit uploaded photo)"; id = View.generateViewId() }
        mode.addView(textOnly); mode.addView(editPhoto); textOnly.isChecked = true
        layout.addView(mode)

        layout.addView(heading("Describe the photo you want", 17f).apply { setPadding(0, 16, 0, 6) })
        promptBox = EditText(this).apply {
            hint = "Example: cinematic DSLR portrait, blue Royal Enfield, golden-hour light..."
            minLines = 4
            gravity = Gravity.TOP
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        layout.addView(promptBox)

        generateButton = Button(this).apply {
            text = "✨  Generate Image"
            setOnClickListener { generate() }
        }
        layout.addView(generateButton)
        status = heading("Ready. Internet connection required.", 14f).apply {
            setPadding(0, 12, 0, 12)
        }
        layout.addView(status)

        val save = Button(this).apply {
            text = "⬇  Save Image"
            setOnClickListener { saveImage() }
        }
        layout.addView(save)
        setContentView(scroll)
    }

    private fun generate() {
        val prompt = promptBox.text.toString().trim()
        if (prompt.isBlank()) { status.text = "Please enter a prompt."; return }
        val editing = mode.checkedRadioButtonId != mode.getChildAt(0).id
        if (editing && selectedUri == null) {
            status.text = "Photo edit mode ke liye pehle photo upload karo."; return
        }
        generateButton.isEnabled = false
        status.text = "AI image bana raha hai... thoda wait karo."
        lifecycleScope.launch {
            try {
                val bytes = withContext(Dispatchers.IO) {
                    val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
                        .addFormDataPart("prompt", prompt)
                        .addFormDataPart("mode", if (editing) "edit" else "generate")
                    if (editing) {
                        val raw = contentResolver.openInputStream(selectedUri!!)?.use { it.readBytes() }
                            ?: throw Exception("Could not read selected photo")
                        builder.addFormDataPart(
                            "image", "upload.jpg",
                            raw.toRequestBody("application/octet-stream".toMediaType())
                        )
                    }
                    val request = Request.Builder().url(apiUrl).post(builder.build()).build()
                    http.newCall(request).execute().use { response ->
                        val body = response.body?.string() ?: throw Exception("Empty server response")
                        if (!response.isSuccessful) {
                            val message = try { JSONObject(body).optString("error", body) } catch (_: Exception) { body }
                            throw Exception(message)
                        }
                        val encoded = JSONObject(body).getString("image")
                        android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                    }
                }
                resultBytes = bytes
                preview.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
                status.text = "Done! Image ready. Save Image dabao."
            } catch (e: Exception) {
                status.text = "Error: ${e.message ?: "Something went wrong"}"
            } finally {
                generateButton.isEnabled = true
            }
        }
    }

    private fun saveImage() {
        val bytes = resultBytes
        if (bytes == null) { status.text = "Pehle image generate karo."; return }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "JK_AI_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JK AI Studio")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Could not create image file")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            status.text = "Saved in Gallery > Pictures/JK AI Studio"
        } catch (e: Exception) {
            status.text = "Save error: ${e.message}"
        }
    }
}
