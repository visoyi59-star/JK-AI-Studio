import express from "express";
import cors from "cors";
import multer from "multer";
import dotenv from "dotenv";
import { InferenceClient } from "@huggingface/inference";

dotenv.config();
const app = express();
app.use(cors());
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 }
});

const token = process.env.HF_TOKEN;
if (!token) console.warn("HF_TOKEN is missing. Add it to backend/.env");

const client = new InferenceClient(token);

app.get("/", (_req, res) => res.json({ name: "JK AI Studio API", status: "online" }));

app.post("/generate", upload.single("image"), async (req, res) => {
  try {
    const prompt = String(req.body.prompt || "").trim();
    const mode = String(req.body.mode || "generate");
    if (!prompt) return res.status(400).json({ error: "Prompt is required." });
    if (prompt.length > 1500) return res.status(400).json({ error: "Prompt is too long (max 1500 characters)." });

    let imageBlob;
    if (mode === "edit") {
      if (!req.file) return res.status(400).json({ error: "Upload a photo first." });
      // Model/provider availability can vary by account. This model is listed for image-to-image.
      imageBlob = await client.imageToImage({
        model: "black-forest-labs/FLUX.1-Kontext-dev",
        inputs: req.file.buffer,
        parameters: { prompt }
      });
    } else {
      imageBlob = await client.textToImage({
        model: "black-forest-labs/FLUX.1-dev",
        inputs: prompt,
        parameters: {
          width: 768,
          height: 1024,
          num_inference_steps: 25
        }
      });
    }

    const arrayBuffer = await imageBlob.arrayBuffer();
    res.json({ image: Buffer.from(arrayBuffer).toString("base64"), mimeType: "image/png" });
  } catch (err) {
    console.error(err);
    res.status(502).json({
      error: "AI provider error. Check your Hugging Face token, model access, credits, and provider availability.",
      detail: String(err?.message || err).slice(0, 500)
    });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`JK AI Studio API listening on ${port}`));
