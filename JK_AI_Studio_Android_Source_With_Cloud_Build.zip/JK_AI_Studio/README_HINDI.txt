JK AI STUDIO - ANDROID STARTER PROJECT
======================================

Is ZIP mein Android app ka source code aur AI backend dono hain.
Yeh ready-made APK nahi hai. APK banane ke liye Android Studio chahiye.

IMPORTANT:
- AI image generation internet aur Hugging Face token se chalega.
- Free access/credits limited ho sakte hain; unlimited free generation guaranteed nahi.
- HF token ko Android app mein kabhi mat daalna. Token sirf backend/.env mein rakhein.
- Image edit model/provider aapke HF account par available hona zaroori hai.

PART A - HUGGING FACE TOKEN
1. https://huggingface.co par account banayein / login karein.
2. Settings > Access Tokens mein token banayein.
3. Token ko Inference Providers permission dein.
4. backend folder mein .env.example ki copy banayein aur uska naam .env rakhein.
5. .env mein HF_TOKEN=hf_... apna token paste karein.

PART B - BACKEND START
Computer mein Node.js 20+ install karein.
Terminal / CMD mein backend folder kholein aur chalayein:
    npm install
    npm start
Backend default port 3000 par chalega.

Public Android app ke liye backend ko HTTPS hosting par deploy karein.
Local testing mein phone aur computer same Wi-Fi par hon:
- MainActivity.kt mein apiUrl ko http://COMPUTER-LAN-IP:3000/generate karein.
- Example: http://192.168.1.5:3000/generate
- Phone aur computer same Wi-Fi par hon.
- Public deployment mein HTTPS URL use karein.

PART C - ANDROID APP BUILD
1. Android Studio install karein.
2. ZIP extract karein.
3. Android Studio > Open > extracted JK_AI_Studio folder.
4. Gradle sync complete hone dein.
5. app/src/main/java/com/jkai/studio/MainActivity.kt kholein.
6. apiUrl mein apna backend URL daalein:
   private val apiUrl = "https://YOUR-BACKEND-URL/generate"
7. Run dabakar phone connect karein ya emulator use karein.
8. APK banane ke liye Build > Build Bundle(s) / APK(s) > Build APK(s).

APP FEATURES
- Text to Image: bina photo upload kiye prompt se image.
- Photo to Image: photo upload karke prompt ke mutabik edit.
- Gallery mein generated image save.

TROUBLESHOOTING
- 401/403: token ya Inference Providers permission check karein.
- 402/429: credits, billing ya rate limit issue ho sakta hai.
- Model not supported: Hugging Face par us model ke supported provider ko check karein.
- Network error: backend HTTPS URL / local IP / firewall check karein.
- Image edit fail: FLUX Kontext model ka access/provider availability account par depend kar sakta hai.

SECURITY BEFORE PUBLIC RELEASE
Yeh starter demo hai. Public users ke liye backend par login, rate limiting,
abuse protection, request-size limits, privacy policy aur usage limits add karein.
